package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/viewemp")
public class ViewEmpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	int row;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			try {
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jsp_servlet_crud", "root", "root");
				String sql;
				sql = "select * from employee123";
				Statement stmt = con.createStatement();
				rs = stmt.executeQuery(sql);
				out.println("<h1>Fetch Records From Employee....</h1>  ");
				out.println("<table cellspacing='0' width='350px' border='1'>");
				out.println("<tr>");
				out.println("<td> EmpID </td>");
				out.println("<td> Firstname </td>");
				out.println("<td> Lastname </td>");
				out.println("<td> Edit </td>");
				out.println("<td> Delete </td>");
				out.println("</tr>");
				
				while(rs.next())
				  {
					  out.println("<tr>");
					  out.println("<td>" +rs.getString("id") + "</td>");
				  out.println("<td>" + rs.getString("fname") +"</td>");
				  out.println("<td>" + rs.getString("lname") + "</td>");
				  
				  out.println("<td>" + "<a href='Editreturn1?id=" + rs.getString("id") +"'> Edit </a>" + "</td>"); 
				  out.println("<td>" + "<a href='Delete?id=" + rs.getString("id") + "'> Delete </a>" + "</td>"); 
				  out.println("</tr>");
				  }
				 
				  out.print("</table>");

			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} catch (ClassNotFoundException e) {
			out.println("<font color='red'>  Record Failed   </font>");
		}
		
	}

}
