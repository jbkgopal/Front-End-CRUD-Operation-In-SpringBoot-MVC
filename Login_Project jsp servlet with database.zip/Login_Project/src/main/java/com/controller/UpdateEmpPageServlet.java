
package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/EditServlet")
public class UpdateEmpPageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	int row;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		try {
			Class.forName("com.mysql.jdbc.Driver");
			try {
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jsp_servlet_crud", "root", "root");
				String empid = request.getParameter("empid");
				String fname = request.getParameter("fname");
				String lname = request.getParameter("lname");

				pst = con.prepareStatement("update employee123 set fname = ?, lname = ? where id = ?");
				pst.setString(1, fname);
				pst.setString(2, lname);
				pst.setString(3, empid);

				row = pst.executeUpdate();

				out.println("<font color='green'>  Record Updateeeedd   </font>");

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} catch (ClassNotFoundException e) {
			out.println("<font color='red'>  Record Failed   </font>");
		}

	}

}
